from flask import Flask, request, jsonify, send_from_directory, Response
from functools import wraps
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)

# Basic Auth credentials - you should change these!
USERNAME = 'jb'
PASSWORD = 'movejb'

# Database setup
def init_db():
    conn = sqlite3.connect('storage.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS storage (
            id INTEGER PRIMARY KEY,
            date TEXT NOT NULL,
            name TEXT,
            status TEXT,
            vaults TEXT,
            aisles TEXT,
            notes TEXT
        )
    ''')
    conn.commit()
    conn.close()

# Basic authentication decorator
def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

def authenticate():
    return Response(
        'Could not verify your access level for that URL.\n'
        'You have to login with proper credentials', 401,
        {'WWW-Authenticate': 'Basic realm="Login Required"'}
    )

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

# Routes
@app.route('/')
@requires_auth
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/js/<path:filename>')
@requires_auth
def serve_js(filename):
    return send_from_directory('js', filename)

@app.route('/css/<path:filename>')
@requires_auth
def serve_css(filename):
    return send_from_directory('css', filename)

@app.route('/images/<path:filename>')
@requires_auth
def serve_images(filename):
    return send_from_directory('images', filename)

# API Routes
@app.route('/api/storage', methods=['GET'])
@requires_auth
def get_storage():
    conn = sqlite3.connect('storage.db')
    c = conn.cursor()
    c.execute('SELECT * FROM storage')
    rows = c.fetchall()
    conn.close()
    
    # Convert rows to list of dictionaries
    data = []
    for row in rows:
        data.append({
            'id': row[0],
            'date': row[1],
            'name': row[2],
            'status': row[3],
            'vaults': row[4],
            'aisles': row[5],
            'notes': row[6]
        })
    return jsonify(data)

@app.route('/api/storage', methods=['POST'])
@requires_auth
def save_storage():
    data = request.json
    conn = sqlite3.connect('storage.db')
    c = conn.cursor()
    
    # Clear existing data and insert new data
    c.execute('DELETE FROM storage')
    for item in data:
        c.execute('''
            INSERT INTO storage (id, date, name, status, vaults, aisles, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            item['id'],
            item['date'],
            item['name'],
            item['status'],
            item['vaults'],
            item['aisles'],
            item['notes']
        ))
    
    conn.commit()
    conn.close()
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)