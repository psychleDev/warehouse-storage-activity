const API_URL = 'https://bridgeport.pythonanywhere.com/api';
const statusOptions = [
    'STG IN',
    'STG OUT',
    'ACCESS',
    'ACCESS & DELIVER',
    'STG OUT 3rd PARTY',
    'PULL & TRANSFER OUT',
    'Day Off',
    'Dr. Appointment'
];

let data = [];
let hasUnsavedChanges = false;

// Fetch initial data from server
async function fetchData() {
    try {
        const response = await fetch(`${API_URL}/storage`);
        data = await response.json();
        renderTable();
        updateSaveButton();
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

// Save data to server
async function saveData() {
    try {
        await fetch(`${API_URL}/storage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        hasUnsavedChanges = false;
        updateSaveButton();
        alert('Changes saved successfully!');
    } catch (error) {
        console.error('Error saving data:', error);
        alert('Error saving changes. Please try again.');
    }
}

function createStatusDropdown(value, id) {
    const select = document.createElement('select');
    select.onchange = (e) => handleChange(id, 'status', e.target.value);

    statusOptions.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option;
        optionElement.textContent = option;
        if (option === value) optionElement.selected = true;
        select.appendChild(optionElement);
    });

    return select;
}

function handleChange(id, field, value) {
    data = data.map(row =>
        row.id === id ? { ...row, [field]: value } : row
    );
    hasUnsavedChanges = true;
    renderTable();
    updateSaveButton();
}

function addNewRow() {
    const newRow = {
        id: Date.now(),
        date: new Date().toISOString().split('T')[0],
        name: '',
        status: 'STG IN',
        vaults: '',
        aisles: '',
        notes: ''
    };
    data.push(newRow);
    hasUnsavedChanges = true;
    renderTable();
    updateSaveButton();
}

function deleteRow(id) {
    data = data.filter(row => row.id !== id);
    hasUnsavedChanges = true;
    renderTable();
    updateSaveButton();
}

function updateSaveButton() {
    const saveButton = document.getElementById('saveButton');
    if (saveButton) {
        saveButton.disabled = !hasUnsavedChanges;
        saveButton.className = hasUnsavedChanges
            ? 'bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 ml-4'
            : 'bg-gray-300 text-gray-500 px-4 py-2 rounded ml-4 cursor-not-allowed';
    }
}

function renderTable() {
    const tbody = document.getElementById('tableBody');
    tbody.innerHTML = '';

    const headerRow = document.querySelector('thead tr');
    if (headerRow) {
        const headers = headerRow.getElementsByTagName('th');
        if (headers.length >= 6) {
            headers[5].textContent = 'Notes';
        }
    }

    data.forEach(row => {
        const tr = document.createElement('tr');

        // Date
        const dateCell = document.createElement('td');
        dateCell.className = 'border p-2';
        const dateInput = document.createElement('input');
        dateInput.type = 'date';
        dateInput.value = row.date;
        dateInput.onchange = (e) => handleChange(row.id, 'date', e.target.value);
        dateCell.appendChild(dateInput);

        // Name
        const nameCell = document.createElement('td');
        nameCell.className = 'border p-2';
        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.value = row.name;
        nameInput.onchange = (e) => handleChange(row.id, 'name', e.target.value);
        nameCell.appendChild(nameInput);

        // Status
        const statusCell = document.createElement('td');
        statusCell.className = 'border p-2';
        statusCell.appendChild(createStatusDropdown(row.status, row.id));

        // Vaults
        const vaultsCell = document.createElement('td');
        vaultsCell.className = 'border p-2';
        const vaultsInput = document.createElement('input');
        vaultsInput.type = 'text';
        vaultsInput.value = row.vaults;
        vaultsInput.onchange = (e) => handleChange(row.id, 'vaults', e.target.value);
        vaultsCell.appendChild(vaultsInput);

        // Aisles
        const aislesCell = document.createElement('td');
        aislesCell.className = 'border p-2';
        const aislesInput = document.createElement('input');
        aislesInput.type = 'text';
        aislesInput.value = row.aisles;
        aislesInput.onchange = (e) => handleChange(row.id, 'aisles', e.target.value);
        aislesCell.appendChild(aislesInput);

        // Notes
        const notesCell = document.createElement('td');
        notesCell.className = 'border p-2';
        const notesInput = document.createElement('textarea');
        notesInput.className = 'w-full p-1 min-h-[60px] resize-y';
        notesInput.value = row.notes || row.outpieces || '';
        notesInput.onchange = (e) => handleChange(row.id, 'notes', e.target.value);
        notesCell.appendChild(notesInput);

        // Actions
        const actionCell = document.createElement('td');
        actionCell.className = 'border p-2';
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.className = 'bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600';
        deleteButton.onclick = () => deleteRow(row.id);
        actionCell.appendChild(deleteButton);

        tr.appendChild(dateCell);
        tr.appendChild(nameCell);
        tr.appendChild(statusCell);
        tr.appendChild(vaultsCell);
        tr.appendChild(aislesCell);
        tr.appendChild(notesCell);
        tr.appendChild(actionCell);

        tbody.appendChild(tr);
    });
}

// Add auto-refresh functionality (but only if there are no unsaved changes)
setInterval(() => {
    if (!hasUnsavedChanges) {
        fetchData();
    }
}, 5000);

// Initial fetch
fetchData();